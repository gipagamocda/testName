﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models
{
    public class photo
    {
        public class Photo
        {
            public int ID { get; set; }

            //public string ImageFile { get; set; } 
            public string Caption { get; set; }
            byte[] Image { get; set; }
        }
    }
}